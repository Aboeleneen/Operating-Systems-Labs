#include <iostream>
#include<pthread.h>
#include<unistd.h>
#include<bits/stdc++.h>

#define NORTH 0
#define EAST 1
#define SOUTH 2
#define WEST 3
using namespace std;
class BAT{
    private:
        int num;
        string dir;
    public:
        BAT(int bat_num , string bat_dir){
            this->num=bat_num;
            this->dir=bat_dir;
        }

        int get_num(){
            return num;
        }

        string get_dir(){
            return dir;
        }
};
class Monitor{
    private:
        //waiting to enter the monitor
        int waiting[4];

        // variables to dedect if there is a car in each section
        int crossing_dir[4];

        // number of cars ready for crossing
        int counter = 0;
        // conditions variables
        pthread_cond_t NorthQueue, EastQueue, SouthQueue,WestQueue,
                       NorthFirst, EastFirst, SouthFirst, WestFirst;
       // mutex for synchronisation
        pthread_mutex_t crossing;

        // hashing directions
        map<string,int> directions;

        // initalize conditions variables with default attributes
        void inti_condition_variables(){
            pthread_cond_init(&NorthQueue,NULL);
            pthread_cond_init(&EastQueue,NULL);
            pthread_cond_init(&SouthQueue,NULL);
            pthread_cond_init(&WestQueue,NULL);
            pthread_cond_init(&NorthFirst,NULL);
            pthread_cond_init(&EastFirst,NULL);
            pthread_cond_init(&SouthFirst,NULL);
            pthread_cond_init(&WestFirst,NULL);
        }



    public:
        Monitor(){
            for(int i=0;i<4;i++){
                waiting[i]=crossing_dir[i]=0;
            }
            directions["North"]=0;
            directions["East"]=1;
            directions["South"]=2;
            directions["West"]=3;
            inti_condition_variables();
            pthread_mutex_init(&crossing,NULL);
        }

        void arrive(BAT b){
            pthread_mutex_lock(&crossing);
            int dir = directions[b.get_dir()];
            if(crossing_dir[dir]!=0){
                    waiting[dir]++;
                    switch(dir){
                        case 0:
                            pthread_cond_wait(&NorthQueue,&crossing);
                            break;
                        case 1:
                            pthread_cond_wait(&EastQueue,&crossing);
                            break;
                        case 2:
                            pthread_cond_wait(&SouthQueue,&crossing);
                            break;
                        case 3:
                            pthread_cond_wait(&WestQueue,&crossing);
                            break;
                    }
                   waiting[dir]--;

            }
            crossing_dir[dir]=1;
            cout << "BAT " << b.get_num() << " from " << b.get_dir() << " arrives at crossing" << endl;
            counter++;
            pthread_mutex_unlock(&crossing);
        }

        void cross(BAT b){
             // code to check traffic from the right, use counters,condition variables etc
            pthread_mutex_lock(&crossing);
            int dir = directions[b.get_dir()];
            // check the intersection for crossing
            if(crossing_dir[(dir+3)%4]!=0){
                    switch(dir){
                        case 0:
                            pthread_cond_wait(&NorthFirst,&crossing);
                            break;
                        case 1:
                            pthread_cond_wait(&EastFirst,&crossing);
                            break;
                        case 2:
                            pthread_cond_wait(&SouthFirst,&crossing);
                            break;
                        case 3:
                            pthread_cond_wait(&WestFirst,&crossing);
                            break;
                    }
            }
            crossing_dir[dir]=0;
            cout << "BAT " << b.get_num() << " from " << b.get_dir() << " crossing" << endl;
            sleep(1); // it takes one second for a BAT to cross
            pthread_mutex_unlock(&crossing);
            // entry section is now available
            switch(dir){
                case 0:
                    pthread_cond_signal(&NorthQueue);
                    break;
                case 1:
                    pthread_cond_signal(&EastQueue);
                    break;
                case 2:
                    pthread_cond_signal(&SouthQueue);
                    break;
                case 3:
                    pthread_cond_signal(&WestQueue);
                    break;
            }
        }
        void leave(BAT b){
            pthread_mutex_lock(&crossing);
            int dir = directions[b.get_dir()];
            counter--;
            cout << "BAT " << b.get_num() << " from " << b.get_dir() << " leaving crossing" << endl;
            crossing_dir[(dir+3)%4]=0;
            // oppsite entry section are now avialable
            switch(dir){
                case 0:
                    if(crossing_dir[0]) pthread_cond_signal(&NorthFirst);
                    else pthread_cond_signal(&WestQueue);
                    break;
                case 1:
                    if(crossing_dir[1]) pthread_cond_signal(&EastFirst);
                    pthread_cond_signal(&NorthQueue);
                    break;
                case 2:
                    if(crossing_dir[2]) pthread_cond_signal(&SouthFirst);
                    pthread_cond_signal(&EastQueue);
                    break;
                case 3:
                    if(crossing_dir[3]) pthread_cond_signal(&WestFirst);
                    pthread_cond_signal(&SouthQueue);
                    break;
            }
            pthread_mutex_unlock(&crossing);
        }
        void check()
        {
         // the manager checks for deadlock and resolves it
        }
};
//global object of monitor
Monitor monitor;
vector<BAT> bats;
void* operation(void* bat){
    int id = *(int*)bat;
    monitor.arrive(bats.at(id));
    monitor.cross(bats.at(id));
    monitor.leave(bats.at(id));
}
int main()
{
    string command ;//= "nnwnsewwewn";
    cin >> command;
    pthread_t th[command.size()];
    for(int i=0;i<command.size();i++){
        if(command[i]=='n') {
            BAT bat(i+1,"North");
            bats.push_back(bat);
        }
        if(command[i]=='e') {
            BAT bat(i+1,"East");
            bats.push_back(bat);
        }
        if(command[i]=='s') {
            BAT bat(i+1,"South");
            bats.push_back(bat);
        }
        if(command[i]=='w') {
            BAT bat(i+1,"West");
            bats.push_back(bat);
        }

    }
    for (int i = 0; i < command.size(); i++) {
    int id = i ;
    pthread_create(&th[i], NULL, &operation, &id);
    }
    for (int i = 0; i < command.size(); i++) {
        pthread_join(th[i], NULL);
    }
    return 0;
}
